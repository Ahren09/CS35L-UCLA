long factor(int n)
{
	long result = 1;
	while (n--)
	{
		result *= n;
	}
	return result;	
}

